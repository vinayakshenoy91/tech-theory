package com.learningreactive.learningreactive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningreactiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
