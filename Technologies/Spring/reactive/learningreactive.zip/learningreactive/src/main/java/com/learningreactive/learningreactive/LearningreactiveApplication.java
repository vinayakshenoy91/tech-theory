package com.learningreactive.learningreactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningreactiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningreactiveApplication.class, args);
	}

}
